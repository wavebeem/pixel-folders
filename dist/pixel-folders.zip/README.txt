Pixelated Folders
=================

https://pixel-folders.wavebeem.com

Build Date: {DATE}


Windows Installation
--------------------

https://www.addictivetips.com/windows-tips/set-custom-folder-icon-windows-10/


Mac Installation
----------------

https://www.macrumors.com/how-to/customize-file-folder-icons-mac/


These icons are licensed under the MIT license.
See LICENSE.txt for license information.


Copyright {YEAR} Brian Mock

https://www.wavebeem.com
