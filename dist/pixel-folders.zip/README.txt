Pixelated Folders
=================

https://pixel-folders.wavebeem.com

Build Date: 2022-08-30 04:01:47 UTC


Windows Installation
--------------------

https://www.addictivetips.com/windows-tips/set-custom-folder-icon-windows-10/


Mac Installation
----------------

https://www.macrumors.com/how-to/customize-file-folder-icons-mac/


These icons are licensed under the MIT license.
See LICENSE.txt for license information.


Copyright 2022 Brian Mock

https://www.wavebeem.com
